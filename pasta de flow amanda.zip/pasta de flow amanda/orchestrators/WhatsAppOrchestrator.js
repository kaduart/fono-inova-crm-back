import { IntentDetector } from '../detectors/index.js';
import * as handlers from '../handlers/index.js';
import Logger from '../services/utils/Logger.js';
import { enrichLeadContext } from '../services/intelligence/enrichLeadContext.js';
import { buildContextPack } from '../services/intelligence/ContextPack.js';
import Lead from '../models/Leads.js';

export class WhatsAppOrchestrator {
    constructor() {
        this.intentDetector = new IntentDetector();
        this.logger = new Logger('WhatsAppOrchestrator');
    }

    async process({ lead, message, context, services }) {
        try {
            if (!services) {
                throw new Error('Services não fornecidos');
            }

            // 🧠 1. ENRIQUECE CONTEXTO (usa seu enrichLeadContext existente!)
            const enrichedContext = await enrichLeadContext(lead._id);

            // 🧠 2. BUILD CONTEXT PACK (usa seu buildContextPack existente!)
            const contextPack = await buildContextPack(lead._id);

            // 🧠 3. Detecta intenção com contexto enriquecido
            const intent = this.intentDetector.detect(message, enrichedContext);

            this.logger.info('Intenção detectada', {
                type: intent.type,
                hasContext: !!enrichedContext.conversationHistory?.length
            });

            // 🧠 4. Seleciona handler
            const handler = this.selectHandler(intent, enrichedContext);

            // 🧠 5. Executa handler com contexto COMPLETO
            const result = await handler.execute({
                lead,
                message,
                context: {
                    ...context,
                    ...enrichedContext,        // Seu contexto existente
                    ...contextPack,            // Seu context pack
                    intent: intent,
                    extractedInfo: {}           // Será preenchido pelo handler
                },
                services
            });

            // 🧠 6. SALVA INFORMAÇÕES EXTRAÍDAS NO LEAD
            await this.saveExtractedInfo(lead._id, result.data?.extractedInfo);

            // 7. Decide comando
            return this.decideCommand({ handlerResult: result });

        } catch (error) {
            this.logger.error('Erro no Orchestrator', error);
            return {
                command: 'SEND_MESSAGE',
                payload: {
                    text: 'Tive um problema técnico aqui 😔 Pode tentar novamente?'
                },
                meta: { error: true }
            };
        }
    }

    // 🆕 MÉTODO: Salva info extraída no lead para reutilização
    async saveExtractedInfo(leadId, extractedInfo) {
        if (!extractedInfo || Object.keys(extractedInfo).length === 0) return;

        try {
            const updateData = {};

            // Idade
            if (extractedInfo.age) {
                updateData.patientAge = extractedInfo.age.age;
                updateData.ageGroup = extractedInfo.age.ageGroup;
            }

            // Terapia detectada
            if (extractedInfo.therapyNeeds?.length > 0) {
                const primary = extractedInfo.therapyNeeds[0];
                updateData.therapyArea = primary.therapy;
                updateData.suggestedTherapy = primary.therapy;
                updateData.symptoms = extractedInfo.therapyNeeds.map(t => t.symptom);
            }

            // Relação (self, child, spouse, etc)
            if (extractedInfo.relationship) {
                updateData.patientRelationship = extractedInfo.relationship;
            }

            // Preferências
            if (extractedInfo.timePreference) {
                updateData.preferredTime = extractedInfo.timePreference;
            }
            if (extractedInfo.modality) {
                updateData.preferredModality = extractedInfo.modality;
            }

            // Salva no qualificationData também (seu campo existente)
            updateData.qualificationData = {
                extractedContext: extractedInfo,
                lastExtraction: new Date()
            };

            // Atualiza lead
            await Lead.findByIdAndUpdate(leadId, { $set: updateData });

            this.logger.info('Informações extraídas salvas no lead', {
                leadId,
                savedFields: Object.keys(updateData)
            });

        } catch (error) {
            this.logger.error('Erro ao salvar info extraída', error);
            // Não quebra o fluxo, só loga erro
        }
    }

    selectHandler(intent = {}, context = {}) {
        const flags = intent.flags || {};

        // Se já tem terapia e idade no contexto -> Booking direto
        if (context.therapyArea && context.patientAge && flags.wantsSchedule) {
            return handlers.bookingHandler;
        }

        // Se tem terapia mas falta info -> Qualification para completar
        if (context.therapyArea && !context.patientAge && flags.wantsSchedule) {
            return handlers.qualificationHandler; // Pergunta idade
        }

        if (flags.wantsSchedule) {
            return handlers.bookingHandler;
        }

        if (flags.asksPrice) {
            return handlers.productHandler;
        }

        if (flags.mentionsSpeechTherapy || intent.type === 'therapy_question') {
            return handlers.therapyHandler;
        }

        // Default: QualificationHandler (seu existente!)
        return handlers.qualificationHandler;
    }

    decideCommand({ handlerResult }) {
        const { events = [], data } = handlerResult || {};

        if (events?.includes('SLOTS_AVAILABLE')) {
            return {
                command: 'SEND_MESSAGE',
                payload: {
                    type: 'SLOT_OPTIONS',
                    data: data.slots,
                    context: {
                        therapy: data.therapy,
                        patientAge: data.patientAge
                    }
                }
            };
        }

        if (events?.includes('PRODUCT_INFO_PROVIDED')) {
            return {
                command: 'SEND_MESSAGE',
                payload: {
                    type: 'PRODUCT_INFO',
                    text: data.aiResponse,
                    data: data.product
                }
            };
        }

        if (events?.includes('CONTEXT_EXTRACTED') || events?.includes('LEAD_QUALIFIED')) {
            return {
                command: 'SEND_MESSAGE',
                payload: {
                    type: 'QUALIFICATION',
                    text: data.aiResponse,
                    extracted: data.extractedContext || data.qualification,
                    missing: data.missingInfo
                }
            };
        }

        if (data?.fallback) {
            return {
                command: 'SEND_MESSAGE',
                payload: {
                    text: data.aiResponse || 'Pode me explicar um pouquinho melhor?'
                }
            };
        }

        return {
            command: 'NO_REPLY',
            meta: { reason: 'no_action_required' }
        };
    }
}
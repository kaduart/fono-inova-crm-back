import * as leadIntelligence from '../services/intelligence/leadIntelligence.js';
import contextExtractor from '../services/utils/ContextExtractor.js';
import Lead from '../models/Leads.js';
import Logger from '../services/utils/Logger.js';

class LeadQualificationHandler {
    constructor() {
        this.logger = new Logger('LeadQualificationHandler');
    }

    async execute({ lead, message, context, services }) {
        try {
            // 1. Extrai informações da mensagem atual
            const extracted = contextExtractor.extractAll(
                message.content,
                context.extractedInfo || {}
            );

            // 2. Usa seu enrichLeadContext existente (já vem no context!)
            const enrichedContext = context; // Já enriquecido pelo orchestrator

            // 3. Decide próximo passo
            const step = this.decideNextStep(extracted, enrichedContext);

            // 4. Gera resposta inteligente
            const aiResponse = this.generateSmartResponse(step, extracted, enrichedContext);

            return {
                data: {
                    aiResponse: aiResponse,
                    extractedInfo: extracted, // 🎯 ISSO VAI SER SALVO NO LEAD!
                    step: step,
                    missingInfo: this.identifyMissingInfo(extracted)
                },
                events: ['CONTEXT_EXTRACTED']
            };

        } catch (error) {
            this.logger.error('Erro na qualificação', error);
            return {
                data: { fallback: true },
                events: []
            };
        }
    }

    decideNextStep(extracted, context) {
        // Se já tem terapia e idade no contexto (salvo anteriormente)
        if (context.therapyArea && context.patientAge) {
            return 'ready_to_schedule';
        }

        // Se tem terapia agora mas não tem idade
        if (extracted.therapyNeeds?.length > 0 && !extracted.age && !context.patientAge) {
            return 'ask_age';
        }

        // Se tem idade agora mas não tem terapia
        if (extracted.age && !extracted.therapyNeeds && !context.therapyArea) {
            return 'ask_symptoms';
        }

        return 'discovery';
    }

    generateSmartResponse(step, extracted, context) {
        // Usa informações já salvas no contexto!
        const savedTherapy = context.therapyArea;
        const savedAge = context.patientAge;
        const currentTherapy = extracted.therapyNeeds?.[0]?.therapy;
        const currentAge = extracted.age?.age;

        const therapy = currentTherapy || savedTherapy;
        const age = currentAge || savedAge;

        const responses = {
            ready_to_schedule: () => {
                const therapyName = {
                    fonoaudiologia: 'Fonoaudiologia',
                    psicologia: 'Psicologia',
                    fisioterapia: 'Fisioterapia'
                }[therapy];

                return `Perfeito! Já tenho aqui que você precisa de ${therapyName}${age ? ` para ${age} anos` : ''}. Vou verificar os horários disponíveis...`;
            },

            ask_age: () => `Para ${therapy === 'fonoaudiologia' ? 'Fono' : therapy}, qual a idade da criança?`,

            ask_symptoms: () => `E o que está sentindo? Pode me contar os sintomas?`,

            discovery: () => `Olá! Sou a Amanda da Clínica Fono Inova 💚 Para te ajudar, é para você ou para alguém da família? E qual a idade?`
        };

        return (responses[step] || responses.discovery)();
    }

    identifyMissingInfo(extracted) {
        const missing = [];
        if (!extracted.age) missing.push('age');
        if (!extracted.therapyNeeds) missing.push('therapy');
        return missing;
    }
}

export default new LeadQualificationHandler();
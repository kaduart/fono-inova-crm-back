import IntentDetector from './IntentDetector.js';
import TherapyDetector from './TherapyDetector.js';

export {
    IntentDetector,
    TherapyDetector
};
